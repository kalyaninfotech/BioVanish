# BioVanish Review - Android Studio Project (Amazon Appstore Ready)

This is the complete, official, standalone Android Studio Project for **BioVanish Review** (`com.biovanish.reviewapp`).

## Configuration
- **App Name**: BioVanish Review
- **Package ID**: `com.biovanish.reviewapp`
- **Target URL**: `https://biovanish.netlify.app/`
- **Compile SDK**: 33 | **Target SDK**: 33 | **Min SDK**: 21
- **Version Code**: 2 | **Version Name**: "2.0"
- **Orientation**: Portrait Only

## How to Open in Android Studio & Generate Signed APK
1. **Extract this ZIP file**: Extract `BioVanish-Android-Project.zip` to a folder on your computer.
2. **Open Android Studio**:
   - Choose **Open** (or File -> Open).
   - Select the extracted `BioVanish-Android-Project` folder.
   - Android Studio will automatically sync the project with Gradle.
3. **Generate Signed APK for Amazon Appstore**:
   - In Android Studio's top menu, click **Build** -> **Generate Signed Bundle / APK...**
   - Select **APK** and click **Next**.
   - Select your existing Keystore or click **Create new...** to create your release keystore.
   - Choose **release** build variant.
   - Check **V1 (Jar Signature)** and **V2 (Full APK Signature)** if shown.
   - Click **Finish**.
4. Android Studio will generate `app-release.apk` located in `app/release/`.
5. Upload this APK directly to the **Amazon Developer Console** under your Amazon Appstore account!
