package com.biovanish.reviewapp;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Target review website URL (replace with your custom Netlify link if needed)
    private static final String TARGET_URL = "https://biovanish.netlify.app/";

    // Custom offline HTML fallback containing '<h1>No Internet Connection</h1>'
    private static final String OFFLINE_HTML = "<!DOCTYPE html>"
            + "<html>"
            + "<head>"
            + "<meta charset='UTF-8'>"
            + "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
            + "<style>"
            + "body { margin: 0; padding: 24px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 90vh; background: #f8faf8; color: #111827; text-align: center; box-sizing: border-box; }"
            + ".icon { width: 72px; height: 72px; border-radius: 50%; background: #fee2e2; color: #dc2626; display: flex; align-items: center; justify-content: center; font-size: 32px; font-weight: bold; margin-bottom: 20px; }"
            + "h1 { font-size: 24px; margin: 0 0 10px 0; color: #111827; }"
            + "p { font-size: 15px; color: #4b5563; margin: 0 0 24px 0; max-width: 320px; line-height: 1.5; }"
            + ".retry-btn { background: #166534; color: #ffffff; border: none; padding: 14px 32px; font-size: 16px; font-weight: 600; border-radius: 12px; cursor: pointer; box-shadow: 0 4px 12px rgba(22, 101, 52, 0.25); text-decoration: none; display: inline-block; }"
            + ".retry-btn:active { background: #14532d; transform: translateY(1px); }"
            + "</style>"
            + "</head>"
            + "<body>"
            + "<div class='icon'>!</div>"
            + "<h1>No Internet Connection</h1>"
            + "<p>Please check your network settings and tap retry to reload the BioVanish review.</p>"
            + "<button class='retry-btn' onclick='location.reload()'>Retry Connection</button>"
            + "</body>"
            + "</html>";

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);

        // Configure WebSettings as required
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setUserAgentString(webSettings.getUserAgentString() + " BioVanishApp/2.0");

        // WebViewClient to stay inside app for review site and handle errors/outbound links
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Keep internal review navigation inside WebView
                if (url.contains("biovanish") || url.contains("netlify.app")) {
                    return false;
                }
                // Open Amazon affiliate or external merchant store links in user's browser
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                    return true;
                } catch (Exception e) {
                    return false;
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    showOfflinePage();
                }
            }
        });

        loadWebsite();
    }

    private void loadWebsite() {
        if (isNetworkConnected()) {
            webView.loadUrl(TARGET_URL);
        } else {
            showOfflinePage();
        }
    }

    private void showOfflinePage() {
        webView.loadDataWithBaseURL(null, OFFLINE_HTML, "text/html", "UTF-8", null);
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            android.net.Network activeNetwork = cm.getActiveNetwork();
            if (activeNetwork == null) return false;
            NetworkCapabilities capabilities = cm.getNetworkCapabilities(activeNetwork);
            return capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
        } else {
            NetworkInfo activeNetworkInfo = cm.getActiveNetworkInfo();
            return activeNetworkInfo != null && activeNetworkInfo.isConnected();
        }
    }

    @Override
    public void onBackPressed() {
        // Handle back button press to navigate WebView history if possible
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
